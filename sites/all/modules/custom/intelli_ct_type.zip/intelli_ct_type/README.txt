
-- SUMMARY --

The Intelliswift Create content type module create a Product Content type by Programmitically
and also We display Product Data and also Provide Product Import by CSV uploder.


-- REQUIREMENTS --

None.


-- INSTALLATION --

* Install as usual, see http://drupal.org/node/895232 for further information.


-- CONFIGURATION --

None.

-- CUSTOMIZATION --

None.

-- TROUBLESHOOTING --

None.

-- FAQ --

None.

-- CONTACT --

None.